docker exec -it docker_csc496 bash 


