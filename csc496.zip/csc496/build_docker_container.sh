docker-compose -f docker/docker-compose-gui.yml build 
docker-compose -f docker/docker-compose-gui.yml create